<?php
/*
Plugin Name: Book Lesson
Description: Themes the WordPress login, registration and forgot password pages according to your theme.
Version: 1.0.0
Author: Slash Tu
Author URI: https://github.com/slashtu
Text Domain: book-lesson
Domain Path: /languages
*/

/**
 * LearnDash Version Constant
 */
define( 'BOOK_LESSON_VERSION', '1.0.0.0' );

if ( !defined('BOOK_LESSSON_LPM_PLUGIN_DIR' ) ) {
  define( 'LEARNDASH_LMS_PLUGIN_DIR', trailingslashit( plugin_dir_path( __FILE__ ) ) );
}
if (!defined( 'BOOK_LESSSON_LPM_PLUGIN_URL' ) ) {
  define( 'LEARNDASH_LMS_PLUGIN_URL', trailingslashit( plugin_dir_url( __FILE__ ) ) );
}

// if ( !defined('LEARNDASH_LMS_DEFAULT_QUESTION_POINTS' ) ) {
//   define( 'LEARNDASH_LMS_DEFAULT_QUESTION_POINTS', 1 );
// }

// if ( !defined('LEARNDASH_LMS_DEFAULT_ANSWER_POINTS' ) ) {
//   define( 'LEARNDASH_LMS_DEFAULT_ANSWER_POINTS', 0 );
}



function foobar_func( $atts ){

  wp_enqueue_script( 'book-lesson', BOOK_LESSSON_LPM_PLUGIN_URL . '/assets/js/book-lesson.js', array( 'jquery' ), BOOK_LESSON_VERSION );

  return "foo and bar";
}
add_shortcode( 'book-lesson', 'foobar_func' );

?>
